
// Importing necessary libraries
import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { FBXLoader } from 'three/addons/loaders/FBXLoader.js';

// Create a loading manager (for assets)
const loadingManager = new THREE.LoadingManager();

// Texture Loader (optional if you are loading textures)
const textureLoader = new THREE.TextureLoader(loadingManager);

// FBXLoader for loading models and animations
const loader = new FBXLoader();
let ninjaAnimMixer;
let homeModel;
let animations = []; // Array to store the loaded animations
let currentAnimationIndex = 0; // To keep track of the current animation

// Load the character model and animations
loader.load('char.fbx', (fbx) => {
    homeModel = fbx;
    homeModel.scale.set(0.02, 0.02, 0.02);
    ninjaAnimMixer = new THREE.AnimationMixer(homeModel);

    // Store all animations in the array
    fbx.animations.forEach((animation) => {
        animations.push(animation);
    });

    // Set the first animation to play
    if (animations.length > 0) {
        playAnimation(animations[0]);
    }

    homeModel.position.x = -2.5;
    scene.add(homeModel);

    // Enable shadows for model meshes
    homeModel.traverse((child) => {
        if (child.isMesh) {
            child.castShadow = true;
            child.receiveShadow = true;
        }
    });

    // Load additional animations
    loadAnimation('Fight idle To Action idle.fbx');
    loadAnimation('Running(2).fbx');
    loadAnimation('Wave Hip Hop Dance.fbx');
    loadAnimation('jumping.fbx');
    loadAnimation('Stable Sword inward Slash.fbx');
});

// Function to play a specific animation
function playAnimation(animation) {
    const animationAction = ninjaAnimMixer.clipAction(animation);
    animationAction.reset();
    animationAction.play();
}

// Function to load animations properly
function loadAnimation(filePath) {
    loader.load(filePath, (anim) => {
        if (anim.animations.length > 0) {
            animations.push(anim.animations[0]);
        }
    });
}

// Canvas and Sizes
let canvas = document.querySelector('.webgl');
let sizes = {
    height: window.innerHeight,
    width: window.innerWidth
};

// Scene
let scene = new THREE.Scene();

// Plane with proper material for lighting
const texture = textureLoader.load('f2.webp');
let planeMesh = new THREE.Mesh(
    new THREE.PlaneGeometry(15, 15),
    new THREE.MeshStandardMaterial()
);
planeMesh.rotation.x = -Math.PI / 2;
planeMesh.receiveShadow = true;
scene.add(planeMesh);

// Environment background
const envTexture = textureLoader.load('back3.jpg');
scene.background = envTexture;
scene.environment = envTexture;

// Lights Setup
const ambientLight = new THREE.AmbientLight('blue', 1.5);
scene.add(ambientLight);

const directionalLight = new THREE.DirectionalLight('blue', 3);
directionalLight.position.set(5, 10, 5);
directionalLight.castShadow = true;
directionalLight.shadow.mapSize.width = 4096;
directionalLight.shadow.mapSize.height = 4096;
directionalLight.shadow.camera.near = 0.1;
directionalLight.shadow.camera.far = 50;
scene.add(directionalLight);

const hemisphereLight = new THREE.HemisphereLight('red', 1.5);
scene.add(hemisphereLight);

const pointLight = new THREE.PointLight('pink', 2, 10);
pointLight.position.set(2, 3, 2);
pointLight.castShadow = true;
scene.add(pointLight);

const spotLight = new THREE.SpotLight('brown', 5);
spotLight.position.set(0, 5, 0);
spotLight.angle = Math.PI / 6;
spotLight.penumbra = 0.5;
spotLight.castShadow = true;
scene.add(spotLight);

// Camera
let aspectRatio = sizes.width / sizes.height;
let camera = new THREE.PerspectiveCamera(45, aspectRatio, 0.1, 100);
camera.position.set(7, 3, 7);
scene.add(camera);

// Renderer
let renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setSize(sizes.width, sizes.height);
renderer.shadowMap.enabled = true;  // Enable shadows
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.render(scene, camera);

// Orbit Controls
let controls = new OrbitControls(camera, canvas);
controls.enableDamping = true;
controls.dampingFactor = 0.01;

// Resize Handler
window.addEventListener('resize', () => {
    sizes.height = window.innerHeight;
    sizes.width = window.innerWidth;

    renderer.setSize(sizes.width, sizes.height);

    aspectRatio = sizes.width / sizes.height;
    camera.aspect = aspectRatio;
    camera.updateProjectionMatrix();

    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio));
    renderer.render(scene, camera);
});

// Mouse position
const mouse = new THREE.Vector2();
window.addEventListener('mousemove', (event) => {
    mouse.x = event.clientX / sizes.width * 2 - 1;
    mouse.y = - (event.clientY / sizes.height) * 2 + 1;
});

// Clock and Animation Loop
let clock = new THREE.Clock();
clock.start();

let animation = () => {
    let deltaTime = clock.getDelta();
    if (ninjaAnimMixer) {
        ninjaAnimMixer.update(deltaTime);
    }

    controls.update();
    renderer.render(scene, camera);
    requestAnimationFrame(animation);
};

// Start animation loop
animation();

// Button logic to switch animations
document.querySelector('button#next').addEventListener('click', () => {
    if (animations.length === 0) return;

    ninjaAnimMixer.stopAllAction();

    currentAnimationIndex = (currentAnimationIndex + 1) % animations.length;

    playAnimation(animations[currentAnimationIndex]);
});
